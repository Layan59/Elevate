const functions = require('firebase-functions');
const admin = require('firebase-admin');
exports.generateQuiz = functions.https.onRequest((req, res) => {
    // Your function logic here
});

// To avoid deployment errors, do not call admin.initializeApp() in your code