import '/backend/api_requests/api_calls.dart';
import '/backend/custom_cloud_functions/custom_cloud_function_response_manager.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'quizzez_widget.dart' show QuizzezWidget;
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuizzezModel extends FlutterFlowModel<QuizzezWidget> {
  ///  Local state fields for this page.

  bool generatingQuiz = false;

  dynamic quiz;

  ///  State fields for stateful widgets in this page.

  // State field(s) for quizSubject widget.
  FocusNode? quizSubjectFocusNode;
  TextEditingController? quizSubjectTextController;
  String? Function(BuildContext, String?)? quizSubjectTextControllerValidator;
  // Stores action output result for [Cloud Function - generateQuiz] action in quizSubject widget.
  GenerateQuizCloudFunctionCallResponse? cloudFunction7ah;
  // Stores action output result for [Backend Call - API (createChatCompletion)] action in quizSubject widget.
  ApiCallResponse? apiResult2eb;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    quizSubjectFocusNode?.dispose();
    quizSubjectTextController?.dispose();
  }
}
