import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "JobseekerPhoto" field.
  String? _jobseekerPhoto;
  String get jobseekerPhoto => _jobseekerPhoto ?? '';
  bool hasJobseekerPhoto() => _jobseekerPhoto != null;

  // "JobseekerUID" field.
  String? _jobseekerUID;
  String get jobseekerUID => _jobseekerUID ?? '';
  bool hasJobseekerUID() => _jobseekerUID != null;

  // "Jobseekercreated_time" field.
  DateTime? _jobseekercreatedTime;
  DateTime? get jobseekercreatedTime => _jobseekercreatedTime;
  bool hasJobseekercreatedTime() => _jobseekercreatedTime != null;

  // "JobseekerPhoneNum" field.
  String? _jobseekerPhoneNum;
  String get jobseekerPhoneNum => _jobseekerPhoneNum ?? '';
  bool hasJobseekerPhoneNum() => _jobseekerPhoneNum != null;

  // "JobseekerFirst_Name" field.
  String? _jobseekerFirstName;
  String get jobseekerFirstName => _jobseekerFirstName ?? '';
  bool hasJobseekerFirstName() => _jobseekerFirstName != null;

  // "JobseekerLast_Name" field.
  String? _jobseekerLastName;
  String get jobseekerLastName => _jobseekerLastName ?? '';
  bool hasJobseekerLastName() => _jobseekerLastName != null;

  // "JobseekerAddress" field.
  String? _jobseekerAddress;
  String get jobseekerAddress => _jobseekerAddress ?? '';
  bool hasJobseekerAddress() => _jobseekerAddress != null;

  // "JobseekerAge" field.
  int? _jobseekerAge;
  int get jobseekerAge => _jobseekerAge ?? 0;
  bool hasJobseekerAge() => _jobseekerAge != null;

  // "JobseekerBio" field.
  String? _jobseekerBio;
  String get jobseekerBio => _jobseekerBio ?? '';
  bool hasJobseekerBio() => _jobseekerBio != null;

  // "JobseekerProfilePic" field.
  String? _jobseekerProfilePic;
  String get jobseekerProfilePic => _jobseekerProfilePic ?? '';
  bool hasJobseekerProfilePic() => _jobseekerProfilePic != null;

  // "JobseekerBackgroundPic" field.
  String? _jobseekerBackgroundPic;
  String get jobseekerBackgroundPic => _jobseekerBackgroundPic ?? '';
  bool hasJobseekerBackgroundPic() => _jobseekerBackgroundPic != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Position" field.
  String? _position;
  String get position => _position ?? '';
  bool hasPosition() => _position != null;

  // "OrganizationLogo" field.
  String? _organizationLogo;
  String get organizationLogo => _organizationLogo ?? '';
  bool hasOrganizationLogo() => _organizationLogo != null;

  // "OrganizationCreatedTime" field.
  DateTime? _organizationCreatedTime;
  DateTime? get organizationCreatedTime => _organizationCreatedTime;
  bool hasOrganizationCreatedTime() => _organizationCreatedTime != null;

  // "OrganizationPhoneNum" field.
  String? _organizationPhoneNum;
  String get organizationPhoneNum => _organizationPhoneNum ?? '';
  bool hasOrganizationPhoneNum() => _organizationPhoneNum != null;

  // "OrganizationName" field.
  String? _organizationName;
  String get organizationName => _organizationName ?? '';
  bool hasOrganizationName() => _organizationName != null;

  // "JobseekerDisplayName" field.
  String? _jobseekerDisplayName;
  String get jobseekerDisplayName => _jobseekerDisplayName ?? '';
  bool hasJobseekerDisplayName() => _jobseekerDisplayName != null;

  // "Password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "ConfirmPassword" field.
  String? _confirmPassword;
  String get confirmPassword => _confirmPassword ?? '';
  bool hasConfirmPassword() => _confirmPassword != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "experience" field.
  String? _experience;
  String get experience => _experience ?? '';
  bool hasExperience() => _experience != null;

  // "skills" field.
  String? _skills;
  String get skills => _skills ?? '';
  bool hasSkills() => _skills != null;

  // "DateOfBirth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "ProfileTitle" field.
  String? _profileTitle;
  String get profileTitle => _profileTitle ?? '';
  bool hasProfileTitle() => _profileTitle != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "userRefs" field.
  List<DocumentReference>? _userRefs;
  List<DocumentReference> get userRefs => _userRefs ?? const [];
  bool hasUserRefs() => _userRefs != null;

  // "JobseekerCity" field.
  String? _jobseekerCity;
  String get jobseekerCity => _jobseekerCity ?? '';
  bool hasJobseekerCity() => _jobseekerCity != null;

  void _initializeFields() {
    _jobseekerPhoto = snapshotData['JobseekerPhoto'] as String?;
    _jobseekerUID = snapshotData['JobseekerUID'] as String?;
    _jobseekercreatedTime = snapshotData['Jobseekercreated_time'] as DateTime?;
    _jobseekerPhoneNum = snapshotData['JobseekerPhoneNum'] as String?;
    _jobseekerFirstName = snapshotData['JobseekerFirst_Name'] as String?;
    _jobseekerLastName = snapshotData['JobseekerLast_Name'] as String?;
    _jobseekerAddress = snapshotData['JobseekerAddress'] as String?;
    _jobseekerAge = castToType<int>(snapshotData['JobseekerAge']);
    _jobseekerBio = snapshotData['JobseekerBio'] as String?;
    _jobseekerProfilePic = snapshotData['JobseekerProfilePic'] as String?;
    _jobseekerBackgroundPic = snapshotData['JobseekerBackgroundPic'] as String?;
    _gender = snapshotData['Gender'] as String?;
    _position = snapshotData['Position'] as String?;
    _organizationLogo = snapshotData['OrganizationLogo'] as String?;
    _organizationCreatedTime =
        snapshotData['OrganizationCreatedTime'] as DateTime?;
    _organizationPhoneNum = snapshotData['OrganizationPhoneNum'] as String?;
    _organizationName = snapshotData['OrganizationName'] as String?;
    _jobseekerDisplayName = snapshotData['JobseekerDisplayName'] as String?;
    _password = snapshotData['Password'] as String?;
    _confirmPassword = snapshotData['ConfirmPassword'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _uid = snapshotData['uid'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _email = snapshotData['email'] as String?;
    _experience = snapshotData['experience'] as String?;
    _skills = snapshotData['skills'] as String?;
    _dateOfBirth = snapshotData['DateOfBirth'] as DateTime?;
    _profileTitle = snapshotData['ProfileTitle'] as String?;
    _education = snapshotData['education'] as String?;
    _city = snapshotData['City'] as String?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _userRefs = getDataList(snapshotData['userRefs']);
    _jobseekerCity = snapshotData['JobseekerCity'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: 'elevate-4ff37')
      .collection('Users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? jobseekerPhoto,
  String? jobseekerUID,
  DateTime? jobseekercreatedTime,
  String? jobseekerPhoneNum,
  String? jobseekerFirstName,
  String? jobseekerLastName,
  String? jobseekerAddress,
  int? jobseekerAge,
  String? jobseekerBio,
  String? jobseekerProfilePic,
  String? jobseekerBackgroundPic,
  String? gender,
  String? position,
  String? organizationLogo,
  DateTime? organizationCreatedTime,
  String? organizationPhoneNum,
  String? organizationName,
  String? jobseekerDisplayName,
  String? password,
  String? confirmPassword,
  String? phoneNumber,
  DateTime? createdTime,
  String? uid,
  String? photoUrl,
  String? displayName,
  String? email,
  String? experience,
  String? skills,
  DateTime? dateOfBirth,
  String? profileTitle,
  String? education,
  String? city,
  DocumentReference? userRef,
  String? jobseekerCity,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'JobseekerPhoto': jobseekerPhoto,
      'JobseekerUID': jobseekerUID,
      'Jobseekercreated_time': jobseekercreatedTime,
      'JobseekerPhoneNum': jobseekerPhoneNum,
      'JobseekerFirst_Name': jobseekerFirstName,
      'JobseekerLast_Name': jobseekerLastName,
      'JobseekerAddress': jobseekerAddress,
      'JobseekerAge': jobseekerAge,
      'JobseekerBio': jobseekerBio,
      'JobseekerProfilePic': jobseekerProfilePic,
      'JobseekerBackgroundPic': jobseekerBackgroundPic,
      'Gender': gender,
      'Position': position,
      'OrganizationLogo': organizationLogo,
      'OrganizationCreatedTime': organizationCreatedTime,
      'OrganizationPhoneNum': organizationPhoneNum,
      'OrganizationName': organizationName,
      'JobseekerDisplayName': jobseekerDisplayName,
      'Password': password,
      'ConfirmPassword': confirmPassword,
      'phone_number': phoneNumber,
      'created_time': createdTime,
      'uid': uid,
      'photo_url': photoUrl,
      'display_name': displayName,
      'email': email,
      'experience': experience,
      'skills': skills,
      'DateOfBirth': dateOfBirth,
      'ProfileTitle': profileTitle,
      'education': education,
      'City': city,
      'userRef': userRef,
      'JobseekerCity': jobseekerCity,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.jobseekerPhoto == e2?.jobseekerPhoto &&
        e1?.jobseekerUID == e2?.jobseekerUID &&
        e1?.jobseekercreatedTime == e2?.jobseekercreatedTime &&
        e1?.jobseekerPhoneNum == e2?.jobseekerPhoneNum &&
        e1?.jobseekerFirstName == e2?.jobseekerFirstName &&
        e1?.jobseekerLastName == e2?.jobseekerLastName &&
        e1?.jobseekerAddress == e2?.jobseekerAddress &&
        e1?.jobseekerAge == e2?.jobseekerAge &&
        e1?.jobseekerBio == e2?.jobseekerBio &&
        e1?.jobseekerProfilePic == e2?.jobseekerProfilePic &&
        e1?.jobseekerBackgroundPic == e2?.jobseekerBackgroundPic &&
        e1?.gender == e2?.gender &&
        e1?.position == e2?.position &&
        e1?.organizationLogo == e2?.organizationLogo &&
        e1?.organizationCreatedTime == e2?.organizationCreatedTime &&
        e1?.organizationPhoneNum == e2?.organizationPhoneNum &&
        e1?.organizationName == e2?.organizationName &&
        e1?.jobseekerDisplayName == e2?.jobseekerDisplayName &&
        e1?.password == e2?.password &&
        e1?.confirmPassword == e2?.confirmPassword &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.createdTime == e2?.createdTime &&
        e1?.uid == e2?.uid &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.displayName == e2?.displayName &&
        e1?.email == e2?.email &&
        e1?.experience == e2?.experience &&
        e1?.skills == e2?.skills &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.profileTitle == e2?.profileTitle &&
        e1?.education == e2?.education &&
        e1?.city == e2?.city &&
        e1?.userRef == e2?.userRef &&
        listEquality.equals(e1?.userRefs, e2?.userRefs) &&
        e1?.jobseekerCity == e2?.jobseekerCity;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.jobseekerPhoto,
        e?.jobseekerUID,
        e?.jobseekercreatedTime,
        e?.jobseekerPhoneNum,
        e?.jobseekerFirstName,
        e?.jobseekerLastName,
        e?.jobseekerAddress,
        e?.jobseekerAge,
        e?.jobseekerBio,
        e?.jobseekerProfilePic,
        e?.jobseekerBackgroundPic,
        e?.gender,
        e?.position,
        e?.organizationLogo,
        e?.organizationCreatedTime,
        e?.organizationPhoneNum,
        e?.organizationName,
        e?.jobseekerDisplayName,
        e?.password,
        e?.confirmPassword,
        e?.phoneNumber,
        e?.createdTime,
        e?.uid,
        e?.photoUrl,
        e?.displayName,
        e?.email,
        e?.experience,
        e?.skills,
        e?.dateOfBirth,
        e?.profileTitle,
        e?.education,
        e?.city,
        e?.userRef,
        e?.userRefs,
        e?.jobseekerCity
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
