import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JobseekerNotificationsRecord extends FirestoreRecord {
  JobseekerNotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "notificationID" field.
  String? _notificationID;
  String get notificationID => _notificationID ?? '';
  bool hasNotificationID() => _notificationID != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "isRead" field.
  bool? _isRead;
  bool get isRead => _isRead ?? false;
  bool hasIsRead() => _isRead != null;

  void _initializeFields() {
    _notificationID = snapshotData['notificationID'] as String?;
    _message = snapshotData['message'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _isRead = snapshotData['isRead'] as bool?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: 'elevate-4ff37')
      .collection('JobseekerNotifications');

  static Stream<JobseekerNotificationsRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => JobseekerNotificationsRecord.fromSnapshot(s));

  static Future<JobseekerNotificationsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => JobseekerNotificationsRecord.fromSnapshot(s));

  static JobseekerNotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JobseekerNotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobseekerNotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobseekerNotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobseekerNotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobseekerNotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobseekerNotificationsRecordData({
  String? notificationID,
  String? message,
  DateTime? timestamp,
  bool? isRead,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'notificationID': notificationID,
      'message': message,
      'timestamp': timestamp,
      'isRead': isRead,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobseekerNotificationsRecordDocumentEquality
    implements Equality<JobseekerNotificationsRecord> {
  const JobseekerNotificationsRecordDocumentEquality();

  @override
  bool equals(
      JobseekerNotificationsRecord? e1, JobseekerNotificationsRecord? e2) {
    return e1?.notificationID == e2?.notificationID &&
        e1?.message == e2?.message &&
        e1?.timestamp == e2?.timestamp &&
        e1?.isRead == e2?.isRead;
  }

  @override
  int hash(JobseekerNotificationsRecord? e) => const ListEquality()
      .hash([e?.notificationID, e?.message, e?.timestamp, e?.isRead]);

  @override
  bool isValidKey(Object? o) => o is JobseekerNotificationsRecord;
}
