import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JobseekerInfoRecord extends FirestoreRecord {
  JobseekerInfoRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "JobseekerFirst_Name" field.
  String? _jobseekerFirstName;
  String get jobseekerFirstName => _jobseekerFirstName ?? '';
  bool hasJobseekerFirstName() => _jobseekerFirstName != null;

  // "JobseekerLast_Name" field.
  String? _jobseekerLastName;
  String get jobseekerLastName => _jobseekerLastName ?? '';
  bool hasJobseekerLastName() => _jobseekerLastName != null;

  // "JobseekerBio" field.
  String? _jobseekerBio;
  String get jobseekerBio => _jobseekerBio ?? '';
  bool hasJobseekerBio() => _jobseekerBio != null;

  // "JobseekerProfilePic" field.
  String? _jobseekerProfilePic;
  String get jobseekerProfilePic => _jobseekerProfilePic ?? '';
  bool hasJobseekerProfilePic() => _jobseekerProfilePic != null;

  // "JobseekerBackgroundPic" field.
  String? _jobseekerBackgroundPic;
  String get jobseekerBackgroundPic => _jobseekerBackgroundPic ?? '';
  bool hasJobseekerBackgroundPic() => _jobseekerBackgroundPic != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Position" field.
  String? _position;
  String get position => _position ?? '';
  bool hasPosition() => _position != null;

  // "Password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "ConfirmPassword" field.
  String? _confirmPassword;
  String get confirmPassword => _confirmPassword ?? '';
  bool hasConfirmPassword() => _confirmPassword != null;

  // "experience" field.
  String? _experience;
  String get experience => _experience ?? '';
  bool hasExperience() => _experience != null;

  // "skills" field.
  String? _skills;
  String get skills => _skills ?? '';
  bool hasSkills() => _skills != null;

  // "DateOfBirth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "ProfileTitle" field.
  String? _profileTitle;
  String get profileTitle => _profileTitle ?? '';
  bool hasProfileTitle() => _profileTitle != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "userRefs" field.
  List<DocumentReference>? _userRefs;
  List<DocumentReference> get userRefs => _userRefs ?? const [];
  bool hasUserRefs() => _userRefs != null;

  // "JobseekerCity" field.
  String? _jobseekerCity;
  String get jobseekerCity => _jobseekerCity ?? '';
  bool hasJobseekerCity() => _jobseekerCity != null;

  // "work_exp" field.
  List<DocumentReference>? _workExp;
  List<DocumentReference> get workExp => _workExp ?? const [];
  bool hasWorkExp() => _workExp != null;

  // "edu_list" field.
  List<DocumentReference>? _eduList;
  List<DocumentReference> get eduList => _eduList ?? const [];
  bool hasEduList() => _eduList != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  void _initializeFields() {
    _jobseekerFirstName = snapshotData['JobseekerFirst_Name'] as String?;
    _jobseekerLastName = snapshotData['JobseekerLast_Name'] as String?;
    _jobseekerBio = snapshotData['JobseekerBio'] as String?;
    _jobseekerProfilePic = snapshotData['JobseekerProfilePic'] as String?;
    _jobseekerBackgroundPic = snapshotData['JobseekerBackgroundPic'] as String?;
    _gender = snapshotData['Gender'] as String?;
    _position = snapshotData['Position'] as String?;
    _password = snapshotData['Password'] as String?;
    _confirmPassword = snapshotData['ConfirmPassword'] as String?;
    _experience = snapshotData['experience'] as String?;
    _skills = snapshotData['skills'] as String?;
    _dateOfBirth = snapshotData['DateOfBirth'] as DateTime?;
    _profileTitle = snapshotData['ProfileTitle'] as String?;
    _education = snapshotData['education'] as String?;
    _city = snapshotData['City'] as String?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _userRefs = getDataList(snapshotData['userRefs']);
    _jobseekerCity = snapshotData['JobseekerCity'] as String?;
    _workExp = getDataList(snapshotData['work_exp']);
    _eduList = getDataList(snapshotData['edu_list']);
    _displayName = snapshotData['display_name'] as String?;
    _email = snapshotData['email'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: 'elevate-4ff37')
      .collection('JobseekerInfo');

  static Stream<JobseekerInfoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JobseekerInfoRecord.fromSnapshot(s));

  static Future<JobseekerInfoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JobseekerInfoRecord.fromSnapshot(s));

  static JobseekerInfoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JobseekerInfoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobseekerInfoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobseekerInfoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobseekerInfoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobseekerInfoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobseekerInfoRecordData({
  String? jobseekerFirstName,
  String? jobseekerLastName,
  String? jobseekerBio,
  String? jobseekerProfilePic,
  String? jobseekerBackgroundPic,
  String? gender,
  String? position,
  String? password,
  String? confirmPassword,
  String? experience,
  String? skills,
  DateTime? dateOfBirth,
  String? profileTitle,
  String? education,
  String? city,
  DocumentReference? userRef,
  String? jobseekerCity,
  String? displayName,
  String? email,
  String? photoUrl,
  String? uid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'JobseekerFirst_Name': jobseekerFirstName,
      'JobseekerLast_Name': jobseekerLastName,
      'JobseekerBio': jobseekerBio,
      'JobseekerProfilePic': jobseekerProfilePic,
      'JobseekerBackgroundPic': jobseekerBackgroundPic,
      'Gender': gender,
      'Position': position,
      'Password': password,
      'ConfirmPassword': confirmPassword,
      'experience': experience,
      'skills': skills,
      'DateOfBirth': dateOfBirth,
      'ProfileTitle': profileTitle,
      'education': education,
      'City': city,
      'userRef': userRef,
      'JobseekerCity': jobseekerCity,
      'display_name': displayName,
      'email': email,
      'photo_url': photoUrl,
      'uid': uid,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobseekerInfoRecordDocumentEquality
    implements Equality<JobseekerInfoRecord> {
  const JobseekerInfoRecordDocumentEquality();

  @override
  bool equals(JobseekerInfoRecord? e1, JobseekerInfoRecord? e2) {
    const listEquality = ListEquality();
    return e1?.jobseekerFirstName == e2?.jobseekerFirstName &&
        e1?.jobseekerLastName == e2?.jobseekerLastName &&
        e1?.jobseekerBio == e2?.jobseekerBio &&
        e1?.jobseekerProfilePic == e2?.jobseekerProfilePic &&
        e1?.jobseekerBackgroundPic == e2?.jobseekerBackgroundPic &&
        e1?.gender == e2?.gender &&
        e1?.position == e2?.position &&
        e1?.password == e2?.password &&
        e1?.confirmPassword == e2?.confirmPassword &&
        e1?.experience == e2?.experience &&
        e1?.skills == e2?.skills &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.profileTitle == e2?.profileTitle &&
        e1?.education == e2?.education &&
        e1?.city == e2?.city &&
        e1?.userRef == e2?.userRef &&
        listEquality.equals(e1?.userRefs, e2?.userRefs) &&
        e1?.jobseekerCity == e2?.jobseekerCity &&
        listEquality.equals(e1?.workExp, e2?.workExp) &&
        listEquality.equals(e1?.eduList, e2?.eduList) &&
        e1?.displayName == e2?.displayName &&
        e1?.email == e2?.email &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid;
  }

  @override
  int hash(JobseekerInfoRecord? e) => const ListEquality().hash([
        e?.jobseekerFirstName,
        e?.jobseekerLastName,
        e?.jobseekerBio,
        e?.jobseekerProfilePic,
        e?.jobseekerBackgroundPic,
        e?.gender,
        e?.position,
        e?.password,
        e?.confirmPassword,
        e?.experience,
        e?.skills,
        e?.dateOfBirth,
        e?.profileTitle,
        e?.education,
        e?.city,
        e?.userRef,
        e?.userRefs,
        e?.jobseekerCity,
        e?.workExp,
        e?.eduList,
        e?.displayName,
        e?.email,
        e?.photoUrl,
        e?.uid
      ]);

  @override
  bool isValidKey(Object? o) => o is JobseekerInfoRecord;
}
