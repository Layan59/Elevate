import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBlfZ3eeuqZw1ZnETKQLpt67bABZW6_yto",
            authDomain: "elevate-4ff37.firebaseapp.com",
            projectId: "elevate-4ff37",
            storageBucket: "elevate-4ff37.appspot.com",
            messagingSenderId: "939053162528",
            appId: "1:939053162528:web:3cd2fb2c9cb62a0eb59c45",
            measurementId: "G-K33WWZ2NGZ"));
  } else {
    await Firebase.initializeApp();
  }
}
