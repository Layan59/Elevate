import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'jobseeker_profile_copy_copy_widget.dart'
    show JobseekerProfileCopyCopyWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class JobseekerProfileCopyCopyModel
    extends FlutterFlowModel<JobseekerProfileCopyCopyWidget> {
  ///  Local state fields for this page.

  List<String> skill = [];
  void addToSkill(String item) => skill.add(item);
  void removeFromSkill(String item) => skill.remove(item);
  void removeAtIndexFromSkill(int index) => skill.removeAt(index);
  void insertAtIndexInSkill(int index, String item) =>
      skill.insert(index, item);
  void updateSkillAtIndex(int index, Function(String) updateFn) =>
      skill[index] = updateFn(skill[index]);

  ///  State fields for stateful widgets in this page.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for bio widget.
  FocusNode? bioFocusNode;
  TextEditingController? bioTextController;
  String? Function(BuildContext, String?)? bioTextControllerValidator;
  // State field(s) for Ad widget.
  FocusNode? adFocusNode;
  TextEditingController? adTextController;
  String? Function(BuildContext, String?)? adTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    bioFocusNode?.dispose();
    bioTextController?.dispose();

    adFocusNode?.dispose();
    adTextController?.dispose();
  }
}
