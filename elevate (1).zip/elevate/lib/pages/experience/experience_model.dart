import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'experience_widget.dart' show ExperienceWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ExperienceModel extends FlutterFlowModel<ExperienceWidget> {
  ///  Local state fields for this page.

  DateTime? endDate;

  DateTime? startDate;

  ///  State fields for stateful widgets in this page.

  // State field(s) for CompanName widget.
  FocusNode? companNameFocusNode;
  TextEditingController? companNameTextController;
  String? Function(BuildContext, String?)? companNameTextControllerValidator;
  // State field(s) for PositionName widget.
  FocusNode? positionNameFocusNode;
  TextEditingController? positionNameTextController;
  String? Function(BuildContext, String?)? positionNameTextControllerValidator;
  // State field(s) for CompanyAddress widget.
  FocusNode? companyAddressFocusNode;
  TextEditingController? companyAddressTextController;
  String? Function(BuildContext, String?)?
      companyAddressTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    companNameFocusNode?.dispose();
    companNameTextController?.dispose();

    positionNameFocusNode?.dispose();
    positionNameTextController?.dispose();

    companyAddressFocusNode?.dispose();
    companyAddressTextController?.dispose();
  }
}
