package com.g18.elevate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
