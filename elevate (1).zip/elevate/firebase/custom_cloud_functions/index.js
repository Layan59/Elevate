const admin = require("firebase-admin/app");
admin.initializeApp();
    
const generateQuiz = require('./generate_quiz.js');
exports.generateQuiz = generateQuiz.generateQuiz;