import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sprint2_copy_model.dart';
export 'sprint2_copy_model.dart';

class Sprint2CopyWidget extends StatefulWidget {
  const Sprint2CopyWidget({super.key});

  @override
  State<Sprint2CopyWidget> createState() => _Sprint2CopyWidgetState();
}

class _Sprint2CopyWidgetState extends State<Sprint2CopyWidget> {
  late Sprint2CopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Sprint2CopyModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter Tight',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: FlutterFlowDropDown<String>(
            controller: _model.cityValueController ??=
                FormFieldController<String>(
              _model.cityValue ??= 'Riyadh',
            ),
            options: List<String>.from([
              'Riyadh',
              'Jeddah',
              'Mecca',
              'Medina',
              'Dammam',
              'Abha',
              'Ad-Dilam',
              'Arar',
              'Dhahran',
              'Dhurma',
              'Dahaban',
              'Diriyah',
              'Dawadmi',
              'Farasan',
              'Ha\'il',
              'Hotat Bani Tamim',
              'Jizan',
              'King Abdullah Economic City',
              'Najran',
              'Al-Namas',
              'Neom',
              'Qatif',
              'Sakakah',
              'Sakakah',
              'Taif',
              'Tabuk',
              'Al-Qassim'
            ]),
            optionLabels: [
              'Riyadh',
              'Jeddah',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              '',
              ''
            ],
            onChanged: (val) async {
              safeSetState(() => _model.cityValue = val);
              await currentUserReference!.update(createUsersRecordData());
            },
            width: 200.0,
            height: 40.0,
            searchHintTextStyle:
                FlutterFlowTheme.of(context).labelMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
            searchTextStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                ),
            textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Inter',
                  letterSpacing: 0.0,
                ),
            hintText: 'City',
            searchHintText: 'Search...',
            icon: Icon(
              Icons.keyboard_arrow_down_rounded,
              color: FlutterFlowTheme.of(context).secondaryText,
              size: 24.0,
            ),
            fillColor: FlutterFlowTheme.of(context).secondaryBackground,
            elevation: 2.0,
            borderColor: Colors.transparent,
            borderWidth: 0.0,
            borderRadius: 8.0,
            margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
            hidesUnderline: true,
            isOverButton: false,
            isSearchable: true,
            isMultiSelect: false,
          ),
        ),
      ),
    );
  }
}
