import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'job_menu_options_widget.dart' show JobMenuOptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class JobMenuOptionsModel extends FlutterFlowModel<JobMenuOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
