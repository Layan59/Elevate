import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'test_taking_quiz_from_job_opp_model.dart';
export 'test_taking_quiz_from_job_opp_model.dart';

class TestTakingQuizFromJobOppWidget extends StatefulWidget {
  const TestTakingQuizFromJobOppWidget({super.key});

  @override
  State<TestTakingQuizFromJobOppWidget> createState() =>
      _TestTakingQuizFromJobOppWidgetState();
}

class _TestTakingQuizFromJobOppWidgetState
    extends State<TestTakingQuizFromJobOppWidget> {
  late TestTakingQuizFromJobOppModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TestTakingQuizFromJobOppModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter Tight',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              StreamBuilder<List<JobCollectionRecord>>(
                stream: queryJobCollectionRecord(
                  queryBuilder: (jobCollectionRecord) => jobCollectionRecord
                      .orderBy('timestamp', descending: true),
                  singleRecord: true,
                ),
                builder: (context, snapshot) {
                  // Customize what your widget looks like when it's loading.
                  if (!snapshot.hasData) {
                    return Center(
                      child: SizedBox(
                        width: 50.0,
                        height: 50.0,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                      ),
                    );
                  }
                  List<JobCollectionRecord> listViewJobCollectionRecordList =
                      snapshot.data!;
                  // Return an empty Container when the item does not exist.
                  if (snapshot.data!.isEmpty) {
                    return Container();
                  }
                  final listViewJobCollectionRecord =
                      listViewJobCollectionRecordList.isNotEmpty
                          ? listViewJobCollectionRecordList.first
                          : null;

                  return ListView(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    children: [
                      Container(
                        width: 396.0,
                        height: 121.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Stack(
                          children: [
                            Align(
                              alignment: AlignmentDirectional(-0.46, -0.02),
                              child: FlutterFlowChoiceChips(
                                options: listViewJobCollectionRecord!.reqSkills
                                    .map((label) => ChipData(label))
                                    .toList(),
                                onChanged: (val) async {
                                  safeSetState(() => _model.choiceChipsValue =
                                      val?.firstOrNull);
                                  _model.selectedSkill =
                                      _model.choiceChipsValue!;
                                  safeSetState(() {});
                                },
                                selectedChipStyle: ChipStyle(
                                  backgroundColor:
                                      FlutterFlowTheme.of(context).primary,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color:
                                            FlutterFlowTheme.of(context).info,
                                        letterSpacing: 0.0,
                                      ),
                                  iconColor: FlutterFlowTheme.of(context).info,
                                  iconSize: 16.0,
                                  elevation: 0.0,
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                unselectedChipStyle: ChipStyle(
                                  backgroundColor: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        letterSpacing: 0.0,
                                      ),
                                  iconColor: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  iconSize: 16.0,
                                  elevation: 0.0,
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                chipSpacing: 8.0,
                                rowSpacing: 8.0,
                                multiselect: false,
                                alignment: WrapAlignment.start,
                                controller:
                                    _model.choiceChipsValueController ??=
                                        FormFieldController<List<String>>(
                                  [],
                                ),
                                wrapped: true,
                              ),
                            ),
                            Align(
                              alignment: AlignmentDirectional(-0.83, -0.75),
                              child: Text(
                                valueOrDefault<String>(
                                  listViewJobCollectionRecord?.jobTitle,
                                  'jobTitle',
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                            Align(
                              alignment: AlignmentDirectional(0.94, 0.69),
                              child: FFButtonWidget(
                                onPressed: () async {
                                  _model.getFirstQuestion =
                                      await GetFirstQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getSecondQuestion =
                                      await GetSecondQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getThirdQuestion =
                                      await GetThirdQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getFourthQuestion =
                                      await GetFourthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getFifthQuestion =
                                      await GetFifthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getSixthQuestion =
                                      await GetSixthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getSeventhQuestion =
                                      await GetSeventhQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getEighthQuestion =
                                      await GetEighthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getNinthQuestion =
                                      await GetNinthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  _model.getTenthQuestion =
                                      await GetTenthQuestionCall.call(
                                    skill: _model.choiceChipsValue,
                                  );

                                  context.pushNamed(
                                    'AIQuizNewCopy',
                                    queryParameters: {
                                      'skill': serializeParam(
                                        _model.selectedSkill,
                                        ParamType.String,
                                      ),
                                      'question1': serializeParam(
                                        getJsonField(
                                          (_model.getFirstQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'quesetion2': serializeParam(
                                        getJsonField(
                                          (_model.getSecondQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question3': serializeParam(
                                        getJsonField(
                                          (_model.getThirdQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question4': serializeParam(
                                        getJsonField(
                                          (_model.getFourthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question5': serializeParam(
                                        getJsonField(
                                          (_model.getFifthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question6': serializeParam(
                                        getJsonField(
                                          (_model.getSixthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question7': serializeParam(
                                        getJsonField(
                                          (_model.getSeventhQuestion
                                                  ?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question8': serializeParam(
                                        getJsonField(
                                          (_model.getEighthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question9': serializeParam(
                                        getJsonField(
                                          (_model.getNinthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'question10': serializeParam(
                                        getJsonField(
                                          (_model.getTenthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString(),
                                        ParamType.String,
                                      ),
                                      'allQuestions': serializeParam(
                                        '${getJsonField(
                                          (_model.getFirstQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getSecondQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getThirdQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getFourthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getFifthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getSixthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getSeventhQuestion
                                                  ?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getEighthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getNinthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}, ${getJsonField(
                                          (_model.getTenthQuestion?.jsonBody ??
                                              ''),
                                          r'''$.choices[:].message.content''',
                                        ).toString()}',
                                        ParamType.String,
                                      ),
                                    }.withoutNulls,
                                  );

                                  safeSetState(() {});
                                },
                                text: 'Take a quiz',
                                options: FFButtonOptions(
                                  width: 120.0,
                                  height: 40.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      16.0, 0.0, 16.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: FlutterFlowTheme.of(context).primary,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .override(
                                        fontFamily: 'Inter Tight',
                                        color: Colors.white,
                                        letterSpacing: 0.0,
                                      ),
                                  elevation: 0.0,
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                            ),
                            Align(
                              alignment: AlignmentDirectional(0.74, -0.85),
                              child: Text(
                                'Hint: tap any skill to take a quiz on',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Inter',
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
