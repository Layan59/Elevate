import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'test_taking_quiz_from_job_opp_widget.dart'
    show TestTakingQuizFromJobOppWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestTakingQuizFromJobOppModel
    extends FlutterFlowModel<TestTakingQuizFromJobOppWidget> {
  ///  Local state fields for this page.

  String jobTitle = 'jobtitle';

  String selectedSkill = 'selectedSkill';

  ///  State fields for stateful widgets in this page.

  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // Stores action output result for [Backend Call - API (GetFirstQuestion)] action in Button widget.
  ApiCallResponse? getFirstQuestion;
  // Stores action output result for [Backend Call - API (GetSecondQuestion)] action in Button widget.
  ApiCallResponse? getSecondQuestion;
  // Stores action output result for [Backend Call - API (GetThirdQuestion)] action in Button widget.
  ApiCallResponse? getThirdQuestion;
  // Stores action output result for [Backend Call - API (GetFourthQuestion)] action in Button widget.
  ApiCallResponse? getFourthQuestion;
  // Stores action output result for [Backend Call - API (GetFifthQuestion)] action in Button widget.
  ApiCallResponse? getFifthQuestion;
  // Stores action output result for [Backend Call - API (GetSixthQuestion)] action in Button widget.
  ApiCallResponse? getSixthQuestion;
  // Stores action output result for [Backend Call - API (GetSeventhQuestion)] action in Button widget.
  ApiCallResponse? getSeventhQuestion;
  // Stores action output result for [Backend Call - API (GetEighthQuestion)] action in Button widget.
  ApiCallResponse? getEighthQuestion;
  // Stores action output result for [Backend Call - API (GetNinthQuestion )] action in Button widget.
  ApiCallResponse? getNinthQuestion;
  // Stores action output result for [Backend Call - API (GetTenthQuestion )] action in Button widget.
  ApiCallResponse? getTenthQuestion;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
