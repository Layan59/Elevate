import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'quiz_details_copy_widget.dart' show QuizDetailsCopyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuizDetailsCopyModel extends FlutterFlowModel<QuizDetailsCopyWidget> {
  ///  Local state fields for this page.

  String? ans1;

  String? ans2;

  String? ans3;

  String? ans4;

  String? ans5;

  String? ans6;

  String? ans7;

  String? ans8;

  String? ans9;

  String? ans10;

  String? userAnswers;

  String? quizData;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
