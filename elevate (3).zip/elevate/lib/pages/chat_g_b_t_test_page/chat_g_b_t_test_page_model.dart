import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'chat_g_b_t_test_page_widget.dart' show ChatGBTTestPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatGBTTestPageModel extends FlutterFlowModel<ChatGBTTestPageWidget> {
  ///  Local state fields for this page.

  String? inputContent;

  dynamic chatHistory;

  ///  State fields for stateful widgets in this page.

  // State field(s) for Column widget.
  ScrollController? columnController;
  // State field(s) for ListView widget.
  ScrollController? listViewController;
  // State field(s) for promptTextFeild widget.
  FocusNode? promptTextFeildFocusNode;
  TextEditingController? promptTextFeildTextController;
  String? Function(BuildContext, String?)?
      promptTextFeildTextControllerValidator;
  // Stores action output result for [Backend Call - API (createChatCompletion)] action in Icon widget.
  ApiCallResponse? chatGBTResponse;

  @override
  void initState(BuildContext context) {
    columnController = ScrollController();
    listViewController = ScrollController();
  }

  @override
  void dispose() {
    columnController?.dispose();
    listViewController?.dispose();
    promptTextFeildFocusNode?.dispose();
    promptTextFeildTextController?.dispose();
  }
}
