import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'quiz_finished_copy_widget.dart' show QuizFinishedCopyWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuizFinishedCopyModel extends FlutterFlowModel<QuizFinishedCopyWidget> {
  ///  Local state fields for this component.

  String quizData =
      '1. What does URL stand for? A. Universal Routing Language B. Uniform Resource Locator\\nC. Unique Resource Link\\nD. United Resource Locator\\n\\n2. Which programming language is commonly used for web development?\\nA. Java\\nB. C++\\nC. Python\\nD. HTML/CSS/JavaScript\\n\\n3. What does CSS stand for in web development?\\nA. Cascading Style Sheets\\nB. Computer Style Sheets\\nC. Creative Style Sheets\\nD. Code Style Sheets\\n\\n4. Which of the following is NOT a web browser?\\nA. Chrome\\nB. Safari\\nC. Java\\nD. Firefox\\n\\n5. What does SEO stand for in the context of websites?\\nA. Search Engine Optimization\\nB. Site Enhancement Optimization\\nC. Social Engagement Outreach\\nD. Search Engine Outreach\\n\\n6. What is the purpose of a web server?\\nA. To store and manage website files\\nB. To design the layout of a website\\nC. To install plugins on a website\\nD. To create content for a website\\n\\n7. Which technology is used for creating responsive web design?\\nA. Flash\\nB. PHP\\nC. Bootstrap\\nD. jQuery\\n\\n8. What is the purpose of a domain name?\\nA. To display ads on a website\\nB. To identify a website on the internet\\nC. To host a website\\nD. To design a website layout\\n\\n9. Which protocol is commonly used for secure web browsing?\\nA. HTTP\\nB. SMTP\\nC. FTP\\nD. HTTPS\\n\\n10. What is the purpose of cookies on a website?\\nA. To track user activity and preferences\\nB. To block access to the website\\nC. To display advertisements\\nD. To design the website layout';

  String answers = 'A, B, C, D, A, D, C, C, D, A';

  String? result;

  String score = '7/10';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
