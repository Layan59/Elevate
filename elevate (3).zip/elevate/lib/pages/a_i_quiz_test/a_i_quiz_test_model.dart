import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'a_i_quiz_test_widget.dart' show AIQuizTestWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AIQuizTestModel extends FlutterFlowModel<AIQuizTestWidget> {
  ///  Local state fields for this page.

  int? questionNum = 1;

  String? question;

  List<String> quizQuestions = [];
  void addToQuizQuestions(String item) => quizQuestions.add(item);
  void removeFromQuizQuestions(String item) => quizQuestions.remove(item);
  void removeAtIndexFromQuizQuestions(int index) =>
      quizQuestions.removeAt(index);
  void insertAtIndexInQuizQuestions(int index, String item) =>
      quizQuestions.insert(index, item);
  void updateQuizQuestionsAtIndex(int index, Function(String) updateFn) =>
      quizQuestions[index] = updateFn(quizQuestions[index]);

  int? currentQuestionIndex = 1;

  ///  State fields for stateful widgets in this page.

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
