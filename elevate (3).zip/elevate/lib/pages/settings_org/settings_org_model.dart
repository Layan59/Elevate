import '/auth/firebase_auth/auth_util.dart';
import '/components/delete_account_widget.dart';
import '/components/organization_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'settings_org_widget.dart' show SettingsOrgWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class SettingsOrgModel extends FlutterFlowModel<SettingsOrgWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for OrganizationNavBar component.
  late OrganizationNavBarModel organizationNavBarModel;

  @override
  void initState(BuildContext context) {
    organizationNavBarModel =
        createModel(context, () => OrganizationNavBarModel());
  }

  @override
  void dispose() {
    organizationNavBarModel.dispose();
  }
}
