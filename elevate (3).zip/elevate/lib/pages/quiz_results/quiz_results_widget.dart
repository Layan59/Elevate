import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'quiz_results_model.dart';
export 'quiz_results_model.dart';

class QuizResultsWidget extends StatefulWidget {
  const QuizResultsWidget({
    super.key,
    this.skill,
    String? quizData,
    this.result,
    this.score,
    this.answers,
  }) : this.quizData = quizData ??
            '1. What does URL stand for? A. Universal Routing Language B. Uniform Resource Locator\\nC. Unique Resource Link\\nD. United Resource Locator\\n\\n2. Which programming language is commonly used for web development?\\nA. Java\\nB. C++\\nC. Python\\nD. HTML/CSS/JavaScript\\n\\n3. What does CSS stand for in web development?\\nA. Cascading Style Sheets\\nB. Computer Style Sheets\\nC. Creative Style Sheets\\nD. Code Style Sheets\\n\\n4. Which of the following is NOT a web browser?\\nA. Chrome\\nB. Safari\\nC. Java\\nD. Firefox\\n\\n5. What does SEO stand for in the context of websites?\\nA. Search Engine Optimization\\nB. Site Enhancement Optimization\\nC. Social Engagement Outreach\\nD. Search Engine Outreach\\n\\n6. What is the purpose of a web server?\\nA. To store and manage website files\\nB. To design the layout of a website\\nC. To install plugins on a website\\nD. To create content for a website\\n\\n7. Which technology is used for creating responsive web design?\\nA. Flash\\nB. PHP\\nC. Bootstrap\\nD. jQuery\\n\\n8. What is the purpose of a domain name?\\nA. To display ads on a website\\nB. To identify a website on the internet\\nC. To host a website\\nD. To design a website layout\\n\\n9. Which protocol is commonly used for secure web browsing?\\nA. HTTP\\nB. SMTP\\nC. FTP\\nD. HTTPS\\n\\n10. What is the purpose of cookies on a website?\\nA. To track user activity and preferences\\nB. To block access to the website\\nC. To display advertisements\\nD. To design the website layout';

  final String? skill;
  final String quizData;
  final String? result;
  final String? score;
  final String? answers;

  @override
  State<QuizResultsWidget> createState() => _QuizResultsWidgetState();
}

class _QuizResultsWidgetState extends State<QuizResultsWidget> {
  late QuizResultsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => QuizResultsModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.quizResult = await CalcQuizResultCall.call(
        quizData: widget!.quizData,
        answers: widget!.answers,
      );

      if ((_model.quizResult?.succeeded ?? true)) {
        _model.result = getJsonField(
          (_model.quizResult?.jsonBody ?? ''),
          r'''$.choices[:].message.content''',
        ).toString().toString();
        safeSetState(() {});
      }
      _model.quizScore = await CalcQuizScoreCall.call(
        quizData: widget!.quizData,
        answers: widget!.answers,
      );

      if ((_model.quizScore?.succeeded ?? true)) {
        _model.score = getJsonField(
          (_model.quizScore?.jsonBody ?? ''),
          r'''$.choices[:].message.content''',
        ).toString().toString();
        safeSetState(() {});
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: 155.0,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF6A5ACD), Color(0xFF9370DB)],
                    stops: [0.0, 1.0],
                    begin: AlignmentDirectional(0.0, -1.0),
                    end: AlignmentDirectional(0, 1.0),
                  ),
                ),
                child: Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          'Quiz Results',
                          style: FlutterFlowTheme.of(context)
                              .headlineLarge
                              .override(
                                fontFamily: 'Inter Tight',
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                                letterSpacing: 0.0,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        Container(
                          width: MediaQuery.sizeOf(context).width * 0.9,
                          height: 1.0,
                          decoration: BoxDecoration(
                            color: Color(0xFFE0E0E0),
                          ),
                        ),
                      ].divide(SizedBox(height: 15.0)),
                    ),
                  ),
                ),
              ),
              Material(
                color: Colors.transparent,
                elevation: 2.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                child: Container(
                  width: MediaQuery.sizeOf(context).width * 0.967,
                  height: 301.0,
                  decoration: BoxDecoration(
                    color: Color(0xFFEAEAFF),
                    borderRadius: BorderRadius.circular(16.0),
                    border: Border.all(
                      color: Color(0xFF7C6FF1),
                      width: 1.0,
                    ),
                  ),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
                    child: SingleChildScrollView(
                      primary: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(-1.0, -1.0),
                                child: Icon(
                                  Icons.smart_toy,
                                  color: Color(0xFF9370DB),
                                  size: 24.0,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  _model.result,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: Color(0xFF7C6FF1),
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ].divide(SizedBox(width: 12.0)),
                          ),
                        ].divide(SizedBox(height: 12.0)),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 10.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    context.pushNamed('PerformanceNew');
                  },
                  text: 'Performance Page',
                  options: FFButtonOptions(
                    width: MediaQuery.sizeOf(context).width * 0.9,
                    height: 56.0,
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Color(0xFF7C6FF1),
                    textStyle:
                        FlutterFlowTheme.of(context).titleMedium.override(
                              fontFamily: 'Inter Tight',
                              color: Colors.white,
                              letterSpacing: 0.0,
                            ),
                    elevation: 3.0,
                    borderRadius: BorderRadius.circular(28.0),
                  ),
                ),
              ),
            ].divide(SizedBox(height: 9.0)),
          ),
        ),
      ),
    );
  }
}
