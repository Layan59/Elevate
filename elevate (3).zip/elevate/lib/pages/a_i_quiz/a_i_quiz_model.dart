import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/pages/quiz_finished/quiz_finished_widget.dart';
import 'a_i_quiz_widget.dart' show AIQuizWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class AIQuizModel extends FlutterFlowModel<AIQuizWidget> {
  ///  Local state fields for this page.

  String ans1 = 'A';

  String ans2 = 'B';

  String ans3 = 'C';

  String ans4 = 'D';

  String ans5 = 'A';

  String ans6 = 'D';

  String ans7 = 'C';

  String ans8 = 'C';

  String ans9 = 'D';

  String ans10 = 'A';

  String userAnswers = 'A, B, C, D, A, D, C, C, D, A';

  String quizData =
      '1. What does URL stand for? A. Universal Routing Language B. Uniform Resource Locator\\nC. Unique Resource Link\\nD. United Resource Locator\\n\\n2. Which programming language is commonly used for web development?\\nA. Java\\nB. C++\\nC. Python\\nD. HTML/CSS/JavaScript\\n\\n3. What does CSS stand for in web development?\\nA. Cascading Style Sheets\\nB. Computer Style Sheets\\nC. Creative Style Sheets\\nD. Code Style Sheets\\n\\n4. Which of the following is NOT a web browser?\\nA. Chrome\\nB. Safari\\nC. Java\\nD. Firefox\\n\\n5. What does SEO stand for in the context of websites?\\nA. Search Engine Optimization\\nB. Site Enhancement Optimization\\nC. Social Engagement Outreach\\nD. Search Engine Outreach\\n\\n6. What is the purpose of a web server?\\nA. To store and manage website files\\nB. To design the layout of a website\\nC. To install plugins on a website\\nD. To create content for a website\\n\\n7. Which technology is used for creating responsive web design?\\nA. Flash\\nB. PHP\\nC. Bootstrap\\nD. jQuery\\n\\n8. What is the purpose of a domain name?\\nA. To display ads on a website\\nB. To identify a website on the internet\\nC. To host a website\\nD. To design a website layout\\n\\n9. Which protocol is commonly used for secure web browsing?\\nA. HTTP\\nB. SMTP\\nC. FTP\\nD. HTTPS\\n\\n10. What is the purpose of cookies on a website?\\nA. To track user activity and preferences\\nB. To block access to the website\\nC. To display advertisements\\nD. To design the website layout';

  ///  State fields for stateful widgets in this page.

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController1;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController2;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController3;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController4;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController5;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController6;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController7;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController8;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController9;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController10;
  // Stores action output result for [Backend Call - API (CalcQuizResult)] action in Button widget.
  ApiCallResponse? quizResult;
  // Stores action output result for [Backend Call - API (CalcQuizScore)] action in Button widget.
  ApiCallResponse? quizScore;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Additional helper methods.
  String? get radioButtonValue1 => radioButtonValueController1?.value;
  String? get radioButtonValue2 => radioButtonValueController2?.value;
  String? get radioButtonValue3 => radioButtonValueController3?.value;
  String? get radioButtonValue4 => radioButtonValueController4?.value;
  String? get radioButtonValue5 => radioButtonValueController5?.value;
  String? get radioButtonValue6 => radioButtonValueController6?.value;
  String? get radioButtonValue7 => radioButtonValueController7?.value;
  String? get radioButtonValue8 => radioButtonValueController8?.value;
  String? get radioButtonValue9 => radioButtonValueController9?.value;
  String? get radioButtonValue10 => radioButtonValueController10?.value;
}
