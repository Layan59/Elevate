import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'start_quiz_page_widget.dart' show StartQuizPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StartQuizPageModel extends FlutterFlowModel<StartQuizPageWidget> {
  ///  Local state fields for this page.

  String? skill;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for SkillField widget.
  FocusNode? skillFieldFocusNode;
  TextEditingController? skillFieldTextController;
  String? Function(BuildContext, String?)? skillFieldTextControllerValidator;
  String? _skillFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // Stores action output result for [Backend Call - API (GetQuiz)] action in Button widget.
  ApiCallResponse? quizResponse;

  @override
  void initState(BuildContext context) {
    skillFieldTextControllerValidator = _skillFieldTextControllerValidator;
  }

  @override
  void dispose() {
    skillFieldFocusNode?.dispose();
    skillFieldTextController?.dispose();
  }
}
