import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'performance_copy_widget.dart' show PerformanceCopyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PerformanceCopyModel extends FlutterFlowModel<PerformanceCopyWidget> {
  ///  Local state fields for this page.

  String? score;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
