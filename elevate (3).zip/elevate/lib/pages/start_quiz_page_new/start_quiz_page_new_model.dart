import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'start_quiz_page_new_widget.dart' show StartQuizPageNewWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StartQuizPageNewModel extends FlutterFlowModel<StartQuizPageNewWidget> {
  ///  Local state fields for this page.

  String? skill;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for SkillField widget.
  FocusNode? skillFieldFocusNode;
  TextEditingController? skillFieldTextController;
  String? Function(BuildContext, String?)? skillFieldTextControllerValidator;
  String? _skillFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 3) {
      return 'Invalid input! skill must be at least 3 charcters long.';
    }
    if (val.length > 25) {
      return 'Invalid input! skill must be at most 25 charcters long.';
    }
    if (!RegExp('^[A-Za-z\\s]+\$').hasMatch(val)) {
      return 'Invalid input! job skills must not contain any special characters,symbols, or digits.';
    }
    return null;
  }

  // Stores action output result for [Backend Call - API (GetFirstQuestion)] action in Button widget.
  ApiCallResponse? getFirstQuestion;
  // Stores action output result for [Backend Call - API (GetSecondQuestion)] action in Button widget.
  ApiCallResponse? getSecondQuestion;
  // Stores action output result for [Backend Call - API (GetThirdQuestion)] action in Button widget.
  ApiCallResponse? getThirdQuestion;
  // Stores action output result for [Backend Call - API (GetFourthQuestion)] action in Button widget.
  ApiCallResponse? getFourthQuestion;
  // Stores action output result for [Backend Call - API (GetFifthQuestion)] action in Button widget.
  ApiCallResponse? getFifthQuestion;
  // Stores action output result for [Backend Call - API (GetSixthQuestion)] action in Button widget.
  ApiCallResponse? getSixthQuestion;
  // Stores action output result for [Backend Call - API (GetSeventhQuestion)] action in Button widget.
  ApiCallResponse? getSeventhQuestion;
  // Stores action output result for [Backend Call - API (GetEighthQuestion)] action in Button widget.
  ApiCallResponse? getEighthQuestion;
  // Stores action output result for [Backend Call - API (GetNinthQuestion )] action in Button widget.
  ApiCallResponse? getNinthQuestion;
  // Stores action output result for [Backend Call - API (GetTenthQuestion )] action in Button widget.
  ApiCallResponse? getTenthQuestion;

  @override
  void initState(BuildContext context) {
    skillFieldTextControllerValidator = _skillFieldTextControllerValidator;
  }

  @override
  void dispose() {
    skillFieldFocusNode?.dispose();
    skillFieldTextController?.dispose();
  }
}
