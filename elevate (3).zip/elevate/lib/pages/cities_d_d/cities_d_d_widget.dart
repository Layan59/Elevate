import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'cities_d_d_model.dart';
export 'cities_d_d_model.dart';

class CitiesDDWidget extends StatefulWidget {
  const CitiesDDWidget({super.key});

  @override
  State<CitiesDDWidget> createState() => _CitiesDDWidgetState();
}

class _CitiesDDWidgetState extends State<CitiesDDWidget> {
  late CitiesDDModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CitiesDDModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Page Title',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Inter Tight',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              FlutterFlowDropDown<String>(
                controller: _model.cityValueController ??=
                    FormFieldController<String>(null),
                options: [
                  'Riyadh',
                  'Jeddah',
                  'Mecca',
                  'Medina',
                  'Dammam',
                  'Abha',
                  'Al-Ahsa',
                  'Al Bahah',
                  'Arar',
                  'Dhahran',
                  'Dhurma',
                  'Dahaban',
                  'Diriyah',
                  'Duba',
                  'Dumat Al-Jandal',
                  'Dawadmi',
                  'Farasan',
                  'Al-Gwei\'iyyah',
                  'Hajrah',
                  'Al-Hareeq',
                  'Ha\'il',
                  'Hotat Bani Tamim',
                  'Hofuf-Al-Mubarraz',
                  'Huraymila',
                  'Hafr Al-Batin',
                  'Jizan',
                  'Jazan Economic City',
                  'Jubail',
                  'Khafji',
                  'King Abdullah Economic City',
                  'Khamis Mushait',
                  'King Khalid Military City',
                  'Knowledge Economic City, Medina',
                  'Khobar',
                  'Muzahmiyya',
                  'Najran',
                  'Al-Namas',
                  'Neom',
                  'Qatif',
                  'Al Qadeeh',
                  'Al-Qassim',
                  'Qurayyat',
                  'Sakakah',
                  'Taif',
                  'Tabuk',
                  'Turaif',
                  'Al-\'Ula',
                  'Wadi Al-Dawasir',
                  'Az Zaimah',
                  'Zulfi'
                ],
                onChanged: (val) async {
                  safeSetState(() => _model.cityValue = val);
                  await currentUserReference!.update(createUsersRecordData());
                },
                width: 200.0,
                height: 40.0,
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Inter',
                      letterSpacing: 0.0,
                    ),
                hintText: 'City',
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: Colors.transparent,
                borderWidth: 0.0,
                borderRadius: 8.0,
                margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                hidesUnderline: true,
                isOverButton: false,
                isSearchable: false,
                isMultiSelect: false,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
