import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'questions_page_test_widget.dart' show QuestionsPageTestWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuestionsPageTestModel extends FlutterFlowModel<QuestionsPageTestWidget> {
  ///  Local state fields for this page.

  int? currentQuestionIndex = 0;

  List<String> questions = [];
  void addToQuestions(String item) => questions.add(item);
  void removeFromQuestions(String item) => questions.remove(item);
  void removeAtIndexFromQuestions(int index) => questions.removeAt(index);
  void insertAtIndexInQuestions(int index, String item) =>
      questions.insert(index, item);
  void updateQuestionsAtIndex(int index, Function(String) updateFn) =>
      questions[index] = updateFn(questions[index]);

  List<String> choices = [];
  void addToChoices(String item) => choices.add(item);
  void removeFromChoices(String item) => choices.remove(item);
  void removeAtIndexFromChoices(int index) => choices.removeAt(index);
  void insertAtIndexInChoices(int index, String item) =>
      choices.insert(index, item);
  void updateChoicesAtIndex(int index, Function(String) updateFn) =>
      choices[index] = updateFn(choices[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
