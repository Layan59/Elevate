import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '../backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: Colors.transparent,
          child: Image.asset(
            'assets/images/dfjsb_6.png',
            fit: BoxFit.cover,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'HomePage': (data) async => ParameterData(
        allParams: {
          'backgroundColor': getParameter<String>(data, 'backgroundColor'),
        },
      ),
  'SignInJobSeeker': ParameterData.none(),
  'SignInOrg': (data) async => ParameterData(
        allParams: {
          'jobseekers': await getDocumentParameter<JobseekerInfoRecord>(
              data, 'jobseekers', JobseekerInfoRecord.fromSnapshot),
        },
      ),
  'SignUpOptions': (data) async => ParameterData(
        allParams: {
          'backgroundColor': getParameter<String>(data, 'backgroundColor'),
        },
      ),
  'SignUpJobseeker': ParameterData.none(),
  'SignUpOrg': ParameterData.none(),
  'CustomizeNotifications': ParameterData.none(),
  'CheckEmail': (data) async => ParameterData(
        allParams: {
          'emailResetField': getParameter<String>(data, 'emailResetField'),
        },
      ),
  'PasswordChangeSuccess': ParameterData.none(),
  'Settings': ParameterData.none(),
  'ForgotPassword': ParameterData.none(),
  'SetNewPassword': ParameterData.none(),
  'JEditprofile': (data) async => ParameterData(
        allParams: {
          'photo': getParameter<String>(data, 'photo'),
          'jobseekerRef': await getDocumentParameter<JobseekerInfoRecord>(
              data, 'jobseekerRef', JobseekerInfoRecord.fromSnapshot),
        },
      ),
  'Sprint2Copy': ParameterData.none(),
  'CitiesDD': ParameterData.none(),
  'Experience': ParameterData.none(),
  'Education': ParameterData.none(),
  'CompleteSignUpJ': (data) async => ParameterData(
        allParams: {
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'JEditprofileCopy': (data) async => ParameterData(
        allParams: {
          'firstName': getParameter<String>(data, 'firstName'),
          'lastName': getParameter<String>(data, 'lastName'),
          'title': getParameter<String>(data, 'title'),
          'education': getParameter<String>(data, 'education'),
          'city': getParameter<String>(data, 'city'),
          'phone': getParameter<String>(data, 'phone'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'StartQuizPage': ParameterData.none(),
  'QuestionsPage': ParameterData.none(),
  'chatGBTTestPage': ParameterData.none(),
  'MainQuizPage': ParameterData.none(),
  'PerformanceOld': (data) async => ParameterData(
        allParams: {
          'userAnswers': getParameter<String>(data, 'userAnswers'),
          'score': getParameter<String>(data, 'score'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'QuestionsPageTest': ParameterData.none(),
  'chatGBTTestPageCopy': ParameterData.none(),
  'AIQuiz': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
        },
      ),
  'AIQuizTest': (data) async => ParameterData(
        allParams: {
          'name': getParameter<String>(data, 'name'),
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
        },
      ),
  'AIQuizNew': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'question1': getParameter<String>(data, 'question1'),
          'quesetion2': getParameter<String>(data, 'quesetion2'),
          'question3': getParameter<String>(data, 'question3'),
          'question4': getParameter<String>(data, 'question4'),
          'question5': getParameter<String>(data, 'question5'),
          'question6': getParameter<String>(data, 'question6'),
          'question7': getParameter<String>(data, 'question7'),
          'question8': getParameter<String>(data, 'question8'),
          'question9': getParameter<String>(data, 'question9'),
          'question10': getParameter<String>(data, 'question10'),
          'allQuestions': getParameter<String>(data, 'allQuestions'),
          'quizCollection': await getDocumentParameter<QuizRecord>(
              data, 'quizCollection', QuizRecord.fromSnapshot),
        },
      ),
  'QuizDetails': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
          'result': getParameter<String>(data, 'result'),
          'score': getParameter<String>(data, 'score'),
          'answers': getParameter<String>(data, 'answers'),
        },
      ),
  'QuizDetailsCopy': (data) async => ParameterData(
        allParams: {
          'name': getParameter<String>(data, 'name'),
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
          'result': getParameter<String>(data, 'result'),
          'score': getParameter<String>(data, 'score'),
        },
      ),
  'QuizResults': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
          'result': getParameter<String>(data, 'result'),
          'score': getParameter<String>(data, 'score'),
          'answers': getParameter<String>(data, 'answers'),
        },
      ),
  'Notifications': (data) async => ParameterData(
        allParams: {
          'users': await getDocumentParameter<UsersRecord>(
              data, 'users', UsersRecord.fromSnapshot),
          'notif': await getDocumentParameter<NotificationsRecord>(
              data, 'notif', NotificationsRecord.fromSnapshot),
        },
      ),
  'JobSeekerProfile': (data) async => ParameterData(
        allParams: {
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'NewJobseekerProfile': ParameterData.none(),
  'NewOrgProfile': ParameterData.none(),
  'sendNotificationsTest': (data) async => ParameterData(
        allParams: {
          'users': await getDocumentParameter<UsersRecord>(
              data, 'users', UsersRecord.fromSnapshot),
        },
      ),
  'OrgViewJobDetails': ParameterData.none(),
  'SettingsOrg': ParameterData.none(),
  'MainQuizPageNew': ParameterData.none(),
  'PerformanceCopy': (data) async => ParameterData(
        allParams: {
          'userAnswers': getParameter<String>(data, 'userAnswers'),
          'score': getParameter<String>(data, 'score'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'StartQuizPageNew': ParameterData.none(),
  'AIQuizCopy2': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'question1': getParameter<String>(data, 'question1'),
          'quesetion2': getParameter<String>(data, 'quesetion2'),
          'question3': getParameter<String>(data, 'question3'),
          'question4': getParameter<String>(data, 'question4'),
          'question5': getParameter<String>(data, 'question5'),
          'question6': getParameter<String>(data, 'question6'),
          'question7': getParameter<String>(data, 'question7'),
          'question8': getParameter<String>(data, 'question8'),
          'question9': getParameter<String>(data, 'question9'),
          'question10': getParameter<String>(data, 'question10'),
        },
      ),
  'uploadPhotoTest': ParameterData.none(),
  'QuizResultsCopy': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'quizData': getParameter<String>(data, 'quizData'),
          'result': getParameter<String>(data, 'result'),
          'score': getParameter<String>(data, 'score'),
          'answers': getParameter<String>(data, 'answers'),
        },
      ),
  'PerformanceNew': (data) async => ParameterData(
        allParams: {
          'userAnswers': getParameter<String>(data, 'userAnswers'),
          'score': getParameter<String>(data, 'score'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'OrgJobs': ParameterData.none(),
  'PostJobDetails': ParameterData.none(),
  'AIQuizNewCopy': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'question1': getParameter<String>(data, 'question1'),
          'quesetion2': getParameter<String>(data, 'quesetion2'),
          'question3': getParameter<String>(data, 'question3'),
          'question4': getParameter<String>(data, 'question4'),
          'question5': getParameter<String>(data, 'question5'),
          'question6': getParameter<String>(data, 'question6'),
          'question7': getParameter<String>(data, 'question7'),
          'question8': getParameter<String>(data, 'question8'),
          'question9': getParameter<String>(data, 'question9'),
          'question10': getParameter<String>(data, 'question10'),
          'allQuestions': getParameter<String>(data, 'allQuestions'),
          'quizCollection': await getDocumentParameter<QuizRecord>(
              data, 'quizCollection', QuizRecord.fromSnapshot),
        },
      ),
  'testTakingQuizFromJobOpp': ParameterData.none(),
  'testAddReqSkills': ParameterData.none(),
  'jobOpportunities': (data) async => ParameterData(
        allParams: {},
      ),
  'testPDF': ParameterData.none(),
  'ApplicableJobSeekers': (data) async => ParameterData(
        allParams: {
          'selectedJob': getParameter<String>(data, 'selectedJob'),
          'skill': getParameter<String>(data, 'skill'),
        },
      ),
  'PostJobDetailsCopy': (data) async => ParameterData(
        allParams: {
          'jobSkill1': getParameter<String>(data, 'jobSkill1'),
          'jobSkill2': getParameter<String>(data, 'jobSkill2'),
          'jobSkill3': getParameter<String>(data, 'jobSkill3'),
        },
      ),
  'OrgJobsDanaCopy': ParameterData.none(),
  'JobseekerViewJobDetails': (data) async => ParameterData(
        allParams: {
          'selectedJobTitle': getParameter<String>(data, 'selectedJobTitle'),
        },
      ),
  'ViewJobDetailsOrg': (data) async => ParameterData(
        allParams: {
          'selectedJobTitle': getParameter<String>(data, 'selectedJobTitle'),
        },
      ),
  'DanaNotifiCopy': (data) async => ParameterData(
        allParams: {
          'users': await getDocumentParameter<UsersRecord>(
              data, 'users', UsersRecord.fromSnapshot),
          'notif': await getDocumentParameter<NotificationsRecord>(
              data, 'notif', NotificationsRecord.fromSnapshot),
        },
      ),
  'OrgEditProfile': (data) async => ParameterData(
        allParams: {
          'firstName': getParameter<String>(data, 'firstName'),
          'lastName': getParameter<String>(data, 'lastName'),
          'title': getParameter<String>(data, 'title'),
          'education': getParameter<String>(data, 'education'),
          'city': getParameter<String>(data, 'city'),
          'phone': getParameter<String>(data, 'phone'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
