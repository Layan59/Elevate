import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyC5UEjgQifKMTesJZpQKnQIa2z9Zjczbu0",
            authDomain: "elevate-p12mni.firebaseapp.com",
            projectId: "elevate-p12mni",
            storageBucket: "elevate-p12mni.appspot.com",
            messagingSenderId: "635480228211",
            appId: "1:635480228211:web:8bae9ab58a0fe2bb23c506"));
  } else {
    await Firebase.initializeApp();
  }
}
