import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PerformanceRecord extends FirestoreRecord {
  PerformanceRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "NumOfQuizes" field.
  int? _numOfQuizes;
  int get numOfQuizes => _numOfQuizes ?? 0;
  bool hasNumOfQuizes() => _numOfQuizes != null;

  // "NumOfQuestions" field.
  int? _numOfQuestions;
  int get numOfQuestions => _numOfQuestions ?? 0;
  bool hasNumOfQuestions() => _numOfQuestions != null;

  // "TotalCorrectAns" field.
  int? _totalCorrectAns;
  int get totalCorrectAns => _totalCorrectAns ?? 0;
  bool hasTotalCorrectAns() => _totalCorrectAns != null;

  // "JobseekerID" field.
  String? _jobseekerID;
  String get jobseekerID => _jobseekerID ?? '';
  bool hasJobseekerID() => _jobseekerID != null;

  void _initializeFields() {
    _numOfQuizes = castToType<int>(snapshotData['NumOfQuizes']);
    _numOfQuestions = castToType<int>(snapshotData['NumOfQuestions']);
    _totalCorrectAns = castToType<int>(snapshotData['TotalCorrectAns']);
    _jobseekerID = snapshotData['JobseekerID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Performance');

  static Stream<PerformanceRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PerformanceRecord.fromSnapshot(s));

  static Future<PerformanceRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PerformanceRecord.fromSnapshot(s));

  static PerformanceRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PerformanceRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PerformanceRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PerformanceRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PerformanceRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PerformanceRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPerformanceRecordData({
  int? numOfQuizes,
  int? numOfQuestions,
  int? totalCorrectAns,
  String? jobseekerID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'NumOfQuizes': numOfQuizes,
      'NumOfQuestions': numOfQuestions,
      'TotalCorrectAns': totalCorrectAns,
      'JobseekerID': jobseekerID,
    }.withoutNulls,
  );

  return firestoreData;
}

class PerformanceRecordDocumentEquality implements Equality<PerformanceRecord> {
  const PerformanceRecordDocumentEquality();

  @override
  bool equals(PerformanceRecord? e1, PerformanceRecord? e2) {
    return e1?.numOfQuizes == e2?.numOfQuizes &&
        e1?.numOfQuestions == e2?.numOfQuestions &&
        e1?.totalCorrectAns == e2?.totalCorrectAns &&
        e1?.jobseekerID == e2?.jobseekerID;
  }

  @override
  int hash(PerformanceRecord? e) => const ListEquality().hash(
      [e?.numOfQuizes, e?.numOfQuestions, e?.totalCorrectAns, e?.jobseekerID]);

  @override
  bool isValidKey(Object? o) => o is PerformanceRecord;
}
