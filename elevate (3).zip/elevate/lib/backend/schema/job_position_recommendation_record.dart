import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JobPositionRecommendationRecord extends FirestoreRecord {
  JobPositionRecommendationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "JobPositionOfRecommendation" field.
  String? _jobPositionOfRecommendation;
  String get jobPositionOfRecommendation => _jobPositionOfRecommendation ?? '';
  bool hasJobPositionOfRecommendation() => _jobPositionOfRecommendation != null;

  // "JobseekerID" field.
  String? _jobseekerID;
  String get jobseekerID => _jobseekerID ?? '';
  bool hasJobseekerID() => _jobseekerID != null;

  // "Recommendation" field.
  String? _recommendation;
  String get recommendation => _recommendation ?? '';
  bool hasRecommendation() => _recommendation != null;

  // "Timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  void _initializeFields() {
    _jobPositionOfRecommendation =
        snapshotData['JobPositionOfRecommendation'] as String?;
    _jobseekerID = snapshotData['JobseekerID'] as String?;
    _recommendation = snapshotData['Recommendation'] as String?;
    _timestamp = snapshotData['Timestamp'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('JobPositionRecommendation');

  static Stream<JobPositionRecommendationRecord> getDocument(
          DocumentReference ref) =>
      ref
          .snapshots()
          .map((s) => JobPositionRecommendationRecord.fromSnapshot(s));

  static Future<JobPositionRecommendationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => JobPositionRecommendationRecord.fromSnapshot(s));

  static JobPositionRecommendationRecord fromSnapshot(
          DocumentSnapshot snapshot) =>
      JobPositionRecommendationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobPositionRecommendationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobPositionRecommendationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobPositionRecommendationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobPositionRecommendationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobPositionRecommendationRecordData({
  String? jobPositionOfRecommendation,
  String? jobseekerID,
  String? recommendation,
  DateTime? timestamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'JobPositionOfRecommendation': jobPositionOfRecommendation,
      'JobseekerID': jobseekerID,
      'Recommendation': recommendation,
      'Timestamp': timestamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobPositionRecommendationRecordDocumentEquality
    implements Equality<JobPositionRecommendationRecord> {
  const JobPositionRecommendationRecordDocumentEquality();

  @override
  bool equals(JobPositionRecommendationRecord? e1,
      JobPositionRecommendationRecord? e2) {
    return e1?.jobPositionOfRecommendation == e2?.jobPositionOfRecommendation &&
        e1?.jobseekerID == e2?.jobseekerID &&
        e1?.recommendation == e2?.recommendation &&
        e1?.timestamp == e2?.timestamp;
  }

  @override
  int hash(JobPositionRecommendationRecord? e) => const ListEquality().hash([
        e?.jobPositionOfRecommendation,
        e?.jobseekerID,
        e?.recommendation,
        e?.timestamp
      ]);

  @override
  bool isValidKey(Object? o) => o is JobPositionRecommendationRecord;
}
