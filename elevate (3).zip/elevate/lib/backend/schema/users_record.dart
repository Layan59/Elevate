import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "ConfirmPassword" field.
  String? _confirmPassword;
  String get confirmPassword => _confirmPassword ?? '';
  bool hasConfirmPassword() => _confirmPassword != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "DateOfBirth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "userRefs" field.
  List<DocumentReference>? _userRefs;
  List<DocumentReference> get userRefs => _userRefs ?? const [];
  bool hasUserRefs() => _userRefs != null;

  // "work_exp" field.
  List<DocumentReference>? _workExp;
  List<DocumentReference> get workExp => _workExp ?? const [];
  bool hasWorkExp() => _workExp != null;

  // "edu_list" field.
  List<DocumentReference>? _eduList;
  List<DocumentReference> get eduList => _eduList ?? const [];
  bool hasEduList() => _eduList != null;

  // "Password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "JobseekerInfoRef" field.
  DocumentReference? _jobseekerInfoRef;
  DocumentReference? get jobseekerInfoRef => _jobseekerInfoRef;
  bool hasJobseekerInfoRef() => _jobseekerInfoRef != null;

  // "JobseekerRef" field.
  List<DocumentReference>? _jobseekerRef;
  List<DocumentReference> get jobseekerRef => _jobseekerRef ?? const [];
  bool hasJobseekerRef() => _jobseekerRef != null;

  // "fcm_tokens" field.
  String? _fcmTokens;
  String get fcmTokens => _fcmTokens ?? '';
  bool hasFcmTokens() => _fcmTokens != null;

  void _initializeFields() {
    _confirmPassword = snapshotData['ConfirmPassword'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _uid = snapshotData['uid'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _email = snapshotData['email'] as String?;
    _dateOfBirth = snapshotData['DateOfBirth'] as DateTime?;
    _education = snapshotData['education'] as String?;
    _city = snapshotData['City'] as String?;
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _userRefs = getDataList(snapshotData['userRefs']);
    _workExp = getDataList(snapshotData['work_exp']);
    _eduList = getDataList(snapshotData['edu_list']);
    _password = snapshotData['Password'] as String?;
    _jobseekerInfoRef = snapshotData['JobseekerInfoRef'] as DocumentReference?;
    _jobseekerRef = getDataList(snapshotData['JobseekerRef']);
    _fcmTokens = snapshotData['fcm_tokens'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? confirmPassword,
  String? phoneNumber,
  DateTime? createdTime,
  String? uid,
  String? photoUrl,
  String? displayName,
  String? email,
  DateTime? dateOfBirth,
  String? education,
  String? city,
  DocumentReference? userRef,
  String? password,
  DocumentReference? jobseekerInfoRef,
  String? fcmTokens,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'ConfirmPassword': confirmPassword,
      'phone_number': phoneNumber,
      'created_time': createdTime,
      'uid': uid,
      'photo_url': photoUrl,
      'display_name': displayName,
      'email': email,
      'DateOfBirth': dateOfBirth,
      'education': education,
      'City': city,
      'userRef': userRef,
      'Password': password,
      'JobseekerInfoRef': jobseekerInfoRef,
      'fcm_tokens': fcmTokens,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.confirmPassword == e2?.confirmPassword &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.createdTime == e2?.createdTime &&
        e1?.uid == e2?.uid &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.displayName == e2?.displayName &&
        e1?.email == e2?.email &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.education == e2?.education &&
        e1?.city == e2?.city &&
        e1?.userRef == e2?.userRef &&
        listEquality.equals(e1?.userRefs, e2?.userRefs) &&
        listEquality.equals(e1?.workExp, e2?.workExp) &&
        listEquality.equals(e1?.eduList, e2?.eduList) &&
        e1?.password == e2?.password &&
        e1?.jobseekerInfoRef == e2?.jobseekerInfoRef &&
        listEquality.equals(e1?.jobseekerRef, e2?.jobseekerRef) &&
        e1?.fcmTokens == e2?.fcmTokens;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.confirmPassword,
        e?.phoneNumber,
        e?.createdTime,
        e?.uid,
        e?.photoUrl,
        e?.displayName,
        e?.email,
        e?.dateOfBirth,
        e?.education,
        e?.city,
        e?.userRef,
        e?.userRefs,
        e?.workExp,
        e?.eduList,
        e?.password,
        e?.jobseekerInfoRef,
        e?.jobseekerRef,
        e?.fcmTokens
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
