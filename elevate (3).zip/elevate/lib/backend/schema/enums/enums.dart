import 'package:collection/collection.dart';

enum Country {
  Afghanistan,
  Albania,
  Algeria,
  Angola,
  AntiguaandBarbuda,
  Argentina,
  Armenia,
  Australia,
  Austria,
  Azerbaijan,
  TheBahamas,
  Bahrain,
  Bangladesh,
  Barbados,
  Brazil,
  Canada,
  Colombia,
  Egypt,
  Ethiopia,
  France,
  Georgia,
  Germany,
  Greece,
  Iraq,
  Italy,
  Japan,
  Jordan,
  Mexico,
  Oman,
  Pakistan,
  Philippines,
  Qatar,
  Russia,
  SaudiArabia,
  Sudan,
  Syria,
  Turkey,
  Ukraine,
  UnitedArabEmirates,
  UnitedKingdom,
  UnitedStates,
  Vietnam,
  Yemen,
  Zimbabwe,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (Country):
      return Country.values.deserialize(value) as T?;
    default:
      return null;
  }
}
