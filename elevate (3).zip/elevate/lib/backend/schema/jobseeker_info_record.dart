import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JobseekerInfoRecord extends FirestoreRecord {
  JobseekerInfoRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "JobseekerFirst_Name" field.
  String? _jobseekerFirstName;
  String get jobseekerFirstName => _jobseekerFirstName ?? '';
  bool hasJobseekerFirstName() => _jobseekerFirstName != null;

  // "JobseekerLast_Name" field.
  String? _jobseekerLastName;
  String get jobseekerLastName => _jobseekerLastName ?? '';
  bool hasJobseekerLastName() => _jobseekerLastName != null;

  // "JobseekerBio" field.
  String? _jobseekerBio;
  String get jobseekerBio => _jobseekerBio ?? '';
  bool hasJobseekerBio() => _jobseekerBio != null;

  // "JobseekerBackgroundPic" field.
  String? _jobseekerBackgroundPic;
  String get jobseekerBackgroundPic => _jobseekerBackgroundPic ?? '';
  bool hasJobseekerBackgroundPic() => _jobseekerBackgroundPic != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "Position" field.
  String? _position;
  String get position => _position ?? '';
  bool hasPosition() => _position != null;

  // "experience" field.
  String? _experience;
  String get experience => _experience ?? '';
  bool hasExperience() => _experience != null;

  // "skills" field.
  String? _skills;
  String get skills => _skills ?? '';
  bool hasSkills() => _skills != null;

  // "DateOfBirth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "ProfileTitle" field.
  String? _profileTitle;
  String get profileTitle => _profileTitle ?? '';
  bool hasProfileTitle() => _profileTitle != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "work_exp" field.
  List<DocumentReference>? _workExp;
  List<DocumentReference> get workExp => _workExp ?? const [];
  bool hasWorkExp() => _workExp != null;

  // "edu_list" field.
  List<DocumentReference>? _eduList;
  List<DocumentReference> get eduList => _eduList ?? const [];
  bool hasEduList() => _eduList != null;

  // "JobseekerProfilePic" field.
  String? _jobseekerProfilePic;
  String get jobseekerProfilePic => _jobseekerProfilePic ?? '';
  bool hasJobseekerProfilePic() => _jobseekerProfilePic != null;

  // "Jphonenumber" field.
  int? _jphonenumber;
  int get jphonenumber => _jphonenumber ?? 0;
  bool hasJphonenumber() => _jphonenumber != null;

  // "Juid" field.
  String? _juid;
  String get juid => _juid ?? '';
  bool hasJuid() => _juid != null;

  // "PDFCV" field.
  String? _pdfcv;
  String get pdfcv => _pdfcv ?? '';
  bool hasPdfcv() => _pdfcv != null;

  // "PdfCv" field.
  String? _pdfCv;
  String get pdfCv => _pdfCv ?? '';
  bool hasPdfCv() => _pdfCv != null;

  void _initializeFields() {
    _jobseekerFirstName = snapshotData['JobseekerFirst_Name'] as String?;
    _jobseekerLastName = snapshotData['JobseekerLast_Name'] as String?;
    _jobseekerBio = snapshotData['JobseekerBio'] as String?;
    _jobseekerBackgroundPic = snapshotData['JobseekerBackgroundPic'] as String?;
    _gender = snapshotData['Gender'] as String?;
    _position = snapshotData['Position'] as String?;
    _experience = snapshotData['experience'] as String?;
    _skills = snapshotData['skills'] as String?;
    _dateOfBirth = snapshotData['DateOfBirth'] as DateTime?;
    _profileTitle = snapshotData['ProfileTitle'] as String?;
    _education = snapshotData['education'] as String?;
    _city = snapshotData['City'] as String?;
    _workExp = getDataList(snapshotData['work_exp']);
    _eduList = getDataList(snapshotData['edu_list']);
    _jobseekerProfilePic = snapshotData['JobseekerProfilePic'] as String?;
    _jphonenumber = castToType<int>(snapshotData['Jphonenumber']);
    _juid = snapshotData['Juid'] as String?;
    _pdfcv = snapshotData['PDFCV'] as String?;
    _pdfCv = snapshotData['PdfCv'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('JobseekerInfo');

  static Stream<JobseekerInfoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JobseekerInfoRecord.fromSnapshot(s));

  static Future<JobseekerInfoRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JobseekerInfoRecord.fromSnapshot(s));

  static JobseekerInfoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JobseekerInfoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobseekerInfoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobseekerInfoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobseekerInfoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobseekerInfoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobseekerInfoRecordData({
  String? jobseekerFirstName,
  String? jobseekerLastName,
  String? jobseekerBio,
  String? jobseekerBackgroundPic,
  String? gender,
  String? position,
  String? experience,
  String? skills,
  DateTime? dateOfBirth,
  String? profileTitle,
  String? education,
  String? city,
  String? jobseekerProfilePic,
  int? jphonenumber,
  String? juid,
  String? pdfcv,
  String? pdfCv,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'JobseekerFirst_Name': jobseekerFirstName,
      'JobseekerLast_Name': jobseekerLastName,
      'JobseekerBio': jobseekerBio,
      'JobseekerBackgroundPic': jobseekerBackgroundPic,
      'Gender': gender,
      'Position': position,
      'experience': experience,
      'skills': skills,
      'DateOfBirth': dateOfBirth,
      'ProfileTitle': profileTitle,
      'education': education,
      'City': city,
      'JobseekerProfilePic': jobseekerProfilePic,
      'Jphonenumber': jphonenumber,
      'Juid': juid,
      'PDFCV': pdfcv,
      'PdfCv': pdfCv,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobseekerInfoRecordDocumentEquality
    implements Equality<JobseekerInfoRecord> {
  const JobseekerInfoRecordDocumentEquality();

  @override
  bool equals(JobseekerInfoRecord? e1, JobseekerInfoRecord? e2) {
    const listEquality = ListEquality();
    return e1?.jobseekerFirstName == e2?.jobseekerFirstName &&
        e1?.jobseekerLastName == e2?.jobseekerLastName &&
        e1?.jobseekerBio == e2?.jobseekerBio &&
        e1?.jobseekerBackgroundPic == e2?.jobseekerBackgroundPic &&
        e1?.gender == e2?.gender &&
        e1?.position == e2?.position &&
        e1?.experience == e2?.experience &&
        e1?.skills == e2?.skills &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.profileTitle == e2?.profileTitle &&
        e1?.education == e2?.education &&
        e1?.city == e2?.city &&
        listEquality.equals(e1?.workExp, e2?.workExp) &&
        listEquality.equals(e1?.eduList, e2?.eduList) &&
        e1?.jobseekerProfilePic == e2?.jobseekerProfilePic &&
        e1?.jphonenumber == e2?.jphonenumber &&
        e1?.juid == e2?.juid &&
        e1?.pdfcv == e2?.pdfcv &&
        e1?.pdfCv == e2?.pdfCv;
  }

  @override
  int hash(JobseekerInfoRecord? e) => const ListEquality().hash([
        e?.jobseekerFirstName,
        e?.jobseekerLastName,
        e?.jobseekerBio,
        e?.jobseekerBackgroundPic,
        e?.gender,
        e?.position,
        e?.experience,
        e?.skills,
        e?.dateOfBirth,
        e?.profileTitle,
        e?.education,
        e?.city,
        e?.workExp,
        e?.eduList,
        e?.jobseekerProfilePic,
        e?.jphonenumber,
        e?.juid,
        e?.pdfcv,
        e?.pdfCv
      ]);

  @override
  bool isValidKey(Object? o) => o is JobseekerInfoRecord;
}
