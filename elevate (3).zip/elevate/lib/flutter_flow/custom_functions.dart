import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/enums/enums.dart';
import '/auth/firebase_auth/auth_util.dart';

dynamic saveChatHistory(
  dynamic chatHistory,
  dynamic newChat,
) {
  // If chatHistory isn't a list, make it a list and then add newChat
  if (chatHistory is List) {
    chatHistory.add(newChat);
    return chatHistory;
  } else {
    return [newChat];
  }
}

dynamic convertToJSON(String prompt) {
// take the prompt and return a JSON with form
  // [{"role": "user", "content": prompt}]
  return json.decode('{"role": "user", "content": "$prompt"}');
}

List<String>? parseQuizData(String? content) {
  List<String> questions = [];

  // Check if content is null or empty
  if (content == null || content.isEmpty) {
    return questions; // Return an empty list
  }

  // Split content by double newlines to separate questions
  List<String> items = content.split('\n\n');

  for (String item in items) {
    // Split each item by newlines to separate the question from the options
    var parts = item.split('\n');
    if (parts.isNotEmpty) {
      String question = parts[0]; // First line is the question
      List<String> options = parts
          .sublist(1)
          .map((option) => option.trim())
          .toList(); // Remaining lines are options

      // Create a formatted string or JSON representation of the question
      questions.add({
        'question': question,
        'options': options,
      }.toString()); // Convert map to string
    }
  }

  return questions;
}
