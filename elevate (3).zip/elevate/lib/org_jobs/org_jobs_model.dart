import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/organization_nav_bar_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'org_jobs_widget.dart' show OrgJobsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OrgJobsModel extends FlutterFlowModel<OrgJobsWidget> {
  ///  Local state fields for this page.

  String selectedjobTitle = 'selectedjobTitle';

  ///  State fields for stateful widgets in this page.

  // Model for OrganizationNavBar component.
  late OrganizationNavBarModel organizationNavBarModel;

  @override
  void initState(BuildContext context) {
    organizationNavBarModel =
        createModel(context, () => OrganizationNavBarModel());
  }

  @override
  void dispose() {
    organizationNavBarModel.dispose();
  }
}
