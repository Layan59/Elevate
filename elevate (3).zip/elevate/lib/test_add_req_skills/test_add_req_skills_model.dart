import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'test_add_req_skills_widget.dart' show TestAddReqSkillsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TestAddReqSkillsModel extends FlutterFlowModel<TestAddReqSkillsWidget> {
  ///  Local state fields for this page.

  String jobSkill1 = 'jobSkill1';

  String jobSkill2 = 'jobSkill2';

  String jobSkill3 = 'jobSkill3';

  List<String> reqSkills = [];
  void addToReqSkills(String item) => reqSkills.add(item);
  void removeFromReqSkills(String item) => reqSkills.remove(item);
  void removeAtIndexFromReqSkills(int index) => reqSkills.removeAt(index);
  void insertAtIndexInReqSkills(int index, String item) =>
      reqSkills.insert(index, item);
  void updateReqSkillsAtIndex(int index, Function(String) updateFn) =>
      reqSkills[index] = updateFn(reqSkills[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for Skill1 widget.
  FocusNode? skill1FocusNode;
  TextEditingController? skill1TextController;
  String? Function(BuildContext, String?)? skill1TextControllerValidator;
  // State field(s) for Skill2 widget.
  FocusNode? skill2FocusNode;
  TextEditingController? skill2TextController;
  String? Function(BuildContext, String?)? skill2TextControllerValidator;
  // State field(s) for Skill3 widget.
  FocusNode? skill3FocusNode;
  TextEditingController? skill3TextController;
  String? Function(BuildContext, String?)? skill3TextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    skill1FocusNode?.dispose();
    skill1TextController?.dispose();

    skill2FocusNode?.dispose();
    skill2TextController?.dispose();

    skill3FocusNode?.dispose();
    skill3TextController?.dispose();
  }
}
