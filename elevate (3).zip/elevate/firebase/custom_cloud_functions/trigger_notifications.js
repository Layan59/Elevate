const functions = require("firebase-functions");
const admin = require("firebase-admin");
// To avoid deployment errors, do not call admin.initializeApp() in your code

exports.triggerNotifications = functions.pubsub
  .schedule("every 2 minutes")
  .onRun(async (context) => {
    const docId = "9xhzfqj8iXM7poScIRhp"; // Your specific document ID
    const notificationRef = admin
      .firestore()
      .collection("Notifications")
      .doc(docId);

    try {
      const notificationDoc = await notificationRef.get();

      if (notificationDoc.exists) {
        const data = notificationDoc.data();
        const message = {
          notification: {
            title: data.title,
            body: data.description, // Use description for the message body
          },
          token: data.userID, // Assuming userID holds the FCM token
        };

        // Send the notification
        const response = await admin.messaging().send(message);
        console.log("Successfully sent message:", response);
      } else {
        console.log("No such document!");
      }
    } catch (error) {
      console.error("Error sending message:", error);
    }
  });
