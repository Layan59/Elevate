const admin = require("firebase-admin/app");
admin.initializeApp();

const generateQuiz = require("./generate_quiz.js");
exports.generateQuiz = generateQuiz.generateQuiz;
const triggerNotifications = require("./trigger_notifications.js");
exports.triggerNotifications = triggerNotifications.triggerNotifications;
